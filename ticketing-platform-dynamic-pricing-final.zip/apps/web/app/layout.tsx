import React from "react";

export const metadata = { title: "Ticketing Platform" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html>
      <body>
        <main style={{ padding: 20, fontFamily: "system-ui, sans-serif" }}>
          <h1>Ticketing Platform</h1>
          {children}
        </main>
      </body>
    </html>
  );
}

import React, { useState } from "react";

export default function MyBookingsPage() {
  const [email, setEmail] = useState("");
  const [bookings, setBookings] = useState<any[]>([]);

  const load = async () => {
    const res = await fetch(`/api/my-bookings?email=${encodeURIComponent(email)}`);
    const data = await res.json();
    setBookings(data);
  };

  return (
    <div>
      <h2>My Bookings</h2>
      <div>
        <input placeholder="your email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <button onClick={load}>Load</button>
      </div>
      <ul>
        {bookings.map((b) => (
          <li key={b.id}>
            Event: {b.event_id} — Qty: {b.quantity} — Paid: ${b.price_paid}
          </li>
        ))}
      </ul>
    </div>
  );
}

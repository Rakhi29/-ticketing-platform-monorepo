import React from "react";
import dynamic from "next/dynamic";

async function fetchEvent(id: string) {
  const res = await fetch(`http://localhost:4000/events/${id}`);
  return res.json();
}

const BookingForm = dynamic(() => import("./form"), { ssr: false });

export default async function EventDetail({ params }: { params: { id: string } }) {
  const id = params.id;
  const event = await fetchEvent(id);

  return (
    <div>
      <h2>{event.name}</h2>
      <div>{event.description}</div>
      <div>Date: {new Date(event.date).toLocaleString()}</div>
      <div>Venue: {event.venue}</div>
      <h3>Price: ${event.priceBreakdown.finalPrice}</h3>
      <pre style={{ background: "#f5f5f5", padding: 12 }}>{JSON.stringify(event.priceBreakdown, null, 2)}</pre>
      <BookingForm eventId={id} remaining={event.remaining} />
    </div>
  );
}

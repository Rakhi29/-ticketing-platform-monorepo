"use client";
import React, { useState } from "react";

export default function BookingForm({ eventId, remaining }: { eventId: string; remaining: number }) {
  const [email, setEmail] = useState("");
  const [qty, setQty] = useState(1);
  const [msg, setMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMsg(null);
    try {
      const res = await fetch("http://localhost:4000/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ eventId: Number(eventId), userEmail: email, quantity: qty })
      });
      const body = await res.json();
      if (!res.ok) {
        setMsg(body.error || "Error booking");
      } else {
        setMsg(`Success: paid $${body.pricePaid}`);
        window.location.href = `/bookings/success?price=${body.pricePaid}&eventId=${eventId}`;
      }
    } catch (err) {
      setMsg("Network error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} style={{ marginTop: 12 }}>
      <div>
        <label>Email</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} required />
      </div>
      <div>
        <label>Quantity (max {remaining})</label>
        <input type="number" value={qty} min={1} max={Math.max(1, remaining)} onChange={(e) => setQty(Number(e.target.value))} required />
      </div>
      <button disabled={loading}>{loading ? "Booking..." : "Book"}</button>
      {msg && <div style={{ marginTop: 8 }}>{msg}</div>}
    </form>
}

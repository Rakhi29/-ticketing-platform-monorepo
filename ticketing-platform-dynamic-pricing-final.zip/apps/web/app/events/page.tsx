import React from "react";

async function fetchEvents() {
  const res = await fetch("http://localhost:4000/events");
  return res.json();
}

export default async function EventsPage() {
  const events = await fetchEvents();

  return (
    <div>
      <h2>Events</h2>
      <ul>
        {events.map((e: any) => (
          <li key={e.id} style={{ marginBottom: 12 }}>
            <a href={`/events/${e.id}`}><strong>{e.name}</strong></a>
            <div>Date: {new Date(e.date).toLocaleString()}</div>
            <div>Venue: {e.venue}</div>
            <div>Price: ${e.price}</div>
            <div>Remaining: {e.remaining}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}

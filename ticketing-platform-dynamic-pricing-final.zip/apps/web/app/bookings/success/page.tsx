import React from "react";

export default function SuccessPage({ searchParams }: { searchParams: { [k: string]: string } }) {
  const { price, eventId } = searchParams;
  return (
    <div>
      <h2>Booking Successful</h2>
      <p>Event ID: {eventId}</p>
      <p>Price paid: ${price}</p>
    </div>
  );
}

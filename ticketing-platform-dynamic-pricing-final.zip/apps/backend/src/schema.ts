import { pgTable, serial, varchar, integer, text, timestamp, numeric, jsonb } from "drizzle-orm/pg-core";

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  venue: varchar("venue", { length: 255 }).notNull(),
  date: timestamp("date").notNull(),
  capacity: integer("capacity").notNull(),
  booked_tickets: integer("booked_tickets").notNull().default(0),
  base_price: numeric("base_price", { precision: 12, scale: 2 }).notNull(),
  floor_price: numeric("floor_price", { precision: 12, scale: 2 }).notNull(),
  ceiling_price: numeric("ceiling_price", { precision: 12, scale: 2 }).notNull(),
  pricing_config: jsonb("pricing_config").notNull().default('{}'),
  created_at: timestamp("created_at").defaultNow().notNull()
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  event_id: integer("event_id").references(() => events.id).notNull(),
  user_email: varchar("user_email", { length: 255 }).notNull(),
  quantity: integer("quantity").notNull(),
  price_paid: numeric("price_paid", { precision: 12, scale: 2 }).notNull(),
  created_at: timestamp("created_at").defaultNow().notNull()
});

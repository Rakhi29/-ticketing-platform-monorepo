import express from "express";
import { db, events, bookings } from "../index";
import { calculatePrice } from "../pricing";

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const rows = await db.select().from(events);
    const now = new Date();
    const out = await Promise.all(
      rows.map(async (r) => {
        const bookingsLastHourRes = await db
          .select()
          .from(bookings)
          .where(bookings.event_id.eq(r.id).and(bookings.created_at.gte(new Date(Date.now() - 1000 * 60 * 60))))
          .then((arr) => arr.length);
        const remaining = Number(r.capacity) - Number(r.booked_tickets);
        const pricingConfig = r.pricing_config as any;
        const pb = calculatePrice(
          Number(r.base_price),
          Number(r.floor_price),
          Number(r.ceiling_price),
          now,
          new Date(r.date),
          pricingConfig,
          { bookingsLastHour: bookingsLastHourRes, remainingTickets: remaining, capacity: Number(r.capacity) }
        );
        return {
          id: r.id,
          name: r.name,
          venue: r.venue,
          date: r.date,
          capacity: r.capacity,
          booked_tickets: r.booked_tickets,
          remaining,
          price: pb.finalPrice
        };
      })
    );
    res.json(out);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "internal" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const r = (await db.select().from(events).where(events.id.eq(id)))[0];
    if (!r) return res.status(404).json({ error: "not found" });
    const bookingsLastHourRes = await db
      .select()
      .from(bookings)
      .where(bookings.event_id.eq(r.id).and(bookings.created_at.gte(new Date(Date.now() - 1000 * 60 * 60))))
      .then((arr) => arr.length);
    const remaining = Number(r.capacity) - Number(r.booked_tickets);
    const pb = calculatePrice(
      Number(r.base_price),
      Number(r.floor_price),
      Number(r.ceiling_price),
      new Date(),
      new Date(r.date),
      r.pricing_config as any,
      { bookingsLastHour: bookingsLastHourRes, remainingTickets: remaining, capacity: Number(r.capacity) }
    );
    res.json({
      ...r,
      remaining,
      priceBreakdown: pb
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "internal" });
  }
});

router.post("/", async (req, res) => {
  const key = req.headers["x-api-key"] || req.query.apiKey;
  if (String(key) !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: "unauthorized" });
  }

  const { name, description, venue, date, capacity, base_price, floor_price, ceiling_price, pricing_config } = req.body;
  if (!name || !venue || !date || !capacity || !base_price) {
    return res.status(400).json({ error: "missing fields" });
  }

  try {
    const inserted = await db.insert(events).values({
      name,
      description,
      venue,
      date: new Date(date),
      capacity,
      booked_tickets: 0,
      base_price,
      floor_price,
      ceiling_price,
      pricing_config: pricing_config ?? {}
    }).returning({ id: events.id });
    res.status(201).json({ id: inserted[0].id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "internal" });
  }
});

export default router;

import express from "express";
import { db, events, bookings } from "../index";
import { sql } from "drizzle-orm";
import { calculatePrice } from "../pricing";

const router = express.Router();

router.post("/", async (req, res) => {
  const { eventId, userEmail, quantity } = req.body;
  const qty = Number(quantity);
  if (!eventId || !userEmail || isNaN(qty) || qty <= 0) return res.status(400).json({ error: "invalid payload" });

  try {
    const result = await db.transaction(async (tx) => {
      const evRows = await tx.select().from(events).where(events.id.eq(eventId)).forUpdate();
      const ev = evRows[0];
      if (!ev) throw { code: "NOT_FOUND" };
      const remaining = Number(ev.capacity) - Number(ev.booked_tickets);
      if (remaining < qty) throw { code: "INSUFFICIENT_SEATS" };

      const oneHourAgo = new Date(Date.now() - 1000 * 60 * 60);
      const bookingsLastHour = (await tx.select().from(bookings).where(bookings.event_id.eq(eventId).and(bookings.created_at.gte(oneHourAgo)))).length;

      const pricingConfig = ev.pricing_config as any;
      const metrics = { bookingsLastHour, remainingTickets: remaining - qty, capacity: Number(ev.capacity) };
      const breakdown = calculatePrice(
        Number(ev.base_price),
        Number(ev.floor_price),
        Number(ev.ceiling_price),
        new Date(),
        new Date(ev.date),
        pricingConfig,
        metrics
      );

      await tx.insert(bookings).values({
        event_id: eventId,
        user_email: userEmail,
        quantity: qty,
        price_paid: breakdown.finalPrice
      });

      await tx.update(events).set({ booked_tickets: sql`${events.booked_tickets} + ${qty}` }).where(events.id.eq(eventId));

      return { success: true, pricePaid: breakdown.finalPrice, breakdown };
    });

    res.json(result);
  } catch (err: any) {
    if (err?.code === "INSUFFICIENT_SEATS") return res.status(409).json({ error: "not enough tickets available" });
    if (err?.code === "NOT_FOUND") return res.status(404).json({ error: "event not found" });
    console.error(err);
    res.status(500).json({ error: "internal" });
  }
});

router.get("/", async (req, res) => {
  const eventId = Number(req.query.eventId);
  try {
    const rows = await db.select().from(bookings).where(bookings.event_id.eq(eventId));
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "internal" });
  }
});

export default router;

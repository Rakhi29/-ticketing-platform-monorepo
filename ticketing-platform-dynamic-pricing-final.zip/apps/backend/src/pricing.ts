export type PricingConfig = {
  timeThresholds?: { in7days?: number; in1day?: number };
  demandThresholds?: { bookingsLastHour?: number; demandIncrease?: number };
  inventoryThresholds?: { lowRemainingPct?: number; inventoryIncrease?: number };
};

export type PriceAdjustmentBreakdown = {
  basePrice: number;
  timeAdjustment: number;
  demandAdjustment: number;
  inventoryAdjustment: number;
  weightedSum: number;
  priceBeforeClamp: number;
  finalPrice: number;
};

export function calculatePrice(
  basePrice: number,
  floor: number,
  ceiling: number,
  now: Date,
  eventDate: Date,
  pricingConfig: PricingConfig,
  metrics: { bookingsLastHour: number; remainingTickets: number; capacity: number },
  weights?: { time: number; demand: number; inventory: number }
): PriceAdjustmentBreakdown {
  const envWeights = {
    time: parseFloat(process.env.PRICE_WEIGHT_TIME ?? "0.4"),
    demand: parseFloat(process.env.PRICE_WEIGHT_DEMAND ?? "0.3"),
    inventory: parseFloat(process.env.PRICE_WEIGHT_INVENTORY ?? "0.3")
  };
  const w = weights ?? envWeights;

  // Time-based
  let timeAdj = 0;
  const diffMs = eventDate.getTime() - now.getTime();
  const diffDays = diffMs / (1000 * 60 * 60 * 24);
  if (pricingConfig.timeThresholds) {
    if (diffDays <= 1 && pricingConfig.timeThresholds.in1day != null) {
      timeAdj = pricingConfig.timeThresholds.in1day;
    } else if (diffDays <= 7 && pricingConfig.timeThresholds.in7days != null) {
      timeAdj = pricingConfig.timeThresholds.in7days;
    } else {
      timeAdj = 0;
    }
  }

  // Demand-based
  let demandAdj = 0;
  if (pricingConfig.demandThresholds) {
    const threshold = pricingConfig.demandThresholds.bookingsLastHour ?? 10;
    const increase = pricingConfig.demandThresholds.demandIncrease ?? 0.15;
    if (metrics.bookingsLastHour > threshold) demandAdj = increase;
  }

  // Inventory-based
  let inventoryAdj = 0;
  if (pricingConfig.inventoryThresholds) {
    const lowPct = pricingConfig.inventoryThresholds.lowRemainingPct ?? 0.2;
    const increase = pricingConfig.inventoryThresholds.inventoryIncrease ?? 0.25;
    const remainingPct = metrics.remainingTickets / Math.max(1, metrics.capacity);
    if (remainingPct <= lowPct) inventoryAdj = increase;
  }

  const weightedSum = w.time * timeAdj + w.demand * demandAdj + w.inventory * inventoryAdj;
  const priceBeforeClamp = basePrice * (1 + weightedSum);
  const finalPrice = Math.min(Math.max(priceBeforeClamp, floor), ceiling);

  return {
    basePrice,
    timeAdjustment: timeAdj,
    demandAdjustment: demandAdj,
    inventoryAdjustment: inventoryAdj,
    weightedSum,
    priceBeforeClamp: Number(priceBeforeClamp.toFixed(2)),
    finalPrice: Number(finalPrice.toFixed(2))
  };
}

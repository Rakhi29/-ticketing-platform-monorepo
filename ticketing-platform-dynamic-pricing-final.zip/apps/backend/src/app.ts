import express from "express";
import eventsRouter from "./routes/events";
import bookingsRouter from "./routes/bookings";
import bodyParser from "body-parser";

const app = express();
app.use(bodyParser.json());
app.use("/events", eventsRouter);
app.use("/bookings", bookingsRouter);

app.get("/analytics/events/:id", async (req, res) => {
  res.json({ message: "analytics endpoint - implement as needed" });
});

app.get("/analytics/summary", async (req, res) => {
  res.json({ message: "system summary - implement as needed" });
});

app.post("/seed", async (req, res) => {
  try {
    const seed = await import("./seed");
    await seed.default();
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "seed failed" });
  }
});

export default app;

import { db } from "./index";
import { events } from "./schema";

export default async function seed() {
  console.log("Seeding...");

  await db.execute(`TRUNCATE TABLE bookings RESTART IDENTITY CASCADE; TRUNCATE TABLE events RESTART IDENTITY CASCADE;`);

  const sample = [
    {
      name: "Indie Rock Night",
      description: "A night of up-and-coming indie rock",
      venue: "Main Hall",
      date: new Date(Date.now() + 1000 * 60 * 60 * 24 * 40),
      capacity: 200,
      booked_tickets: 0,
      base_price: "20.00",
      floor_price: "10.00",
      ceiling_price: "100.00",
      pricing_config: JSON.stringify({
        timeThresholds: { in7days: 0.2, in1day: 0.5 },
        demandThresholds: { bookingsLastHour: 10, demandIncrease: 0.15 },
        inventoryThresholds: { lowRemainingPct: 0.2, inventoryIncrease: 0.25 }
      })
    },
    {
      name: "Tech Talk: AI Futures",
      description: "Panel on where AI is heading",
      venue: "Auditorium",
      date: new Date(Date.now() + 1000 * 60 * 60 * 24 * 5),
      capacity: 100,
      booked_tickets: 20,
      base_price: "50.00",
      floor_price: "20.00",
      ceiling_price: "200.00",
      pricing_config: JSON.stringify({
        timeThresholds: { in7days: 0.2, in1day: 0.5 },
        demandThresholds: { bookingsLastHour: 10, demandIncrease: 0.15 },
        inventoryThresholds: { lowRemainingPct: 0.2, inventoryIncrease: 0.25 }
      })
    }
  ];

  for (const ev of sample) {
    await db.insert(events).values(ev);
  }
  console.log("Seed complete");
}

if (require.main === module) {
  seed().catch((err) => {
    console.error(err);
    process.exit(1);
  });
}

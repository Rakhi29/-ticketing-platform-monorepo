Pricing Algorithm & Design Choices

The pricing engine combines three orthogonal signals—time-to-event, booking velocity (demand), and remaining inventory—into a deterministic formula. Each rule returns a fractional adjustment (for example, 0.2 = +20%). The final price is computed as:

currentPrice = basePrice × (1 + sum(weights_i × adjustment_i))

Weights are configurable via environment variables so the tuning is deployment-specific without code changes. The rule thresholds and nominal increases are stored in an event's `pricing_config` JSON column for per-event customization. After computing the combined adjustment, the price is clamped to the event’s configured floor and ceiling to ensure predictable bounds.

The engine is implemented as a pure function (`calculatePrice`) which receives all inputs (base price, floor/ceiling, now, event date, pricingConfig, metrics). Being pure simplifies unit testing and reproducibility. Unit tests cover each rule independently and combined scenarios and validate floor/ceiling clamping.

Concurrency & Oversell Prevention

Preventing oversell is handled with database-level transaction semantics and row-level locking. When a booking request is processed the backend begins a transaction and selects the corresponding event row `FOR UPDATE`, ensuring other concurrent transactions must wait until the lock is released. Within the same transaction, availability is checked, the booking row is inserted, and the event’s `booked_tickets` is incremented. If availability is insufficient the transaction is rolled back and the client receives a 409 Conflict. A Jest + Supertest integration test simulates two simultaneous booking requests for the last ticket and asserts that one succeeds and one fails, and that the DB contains exactly one booking.

Monorepo Architecture Decisions

The monorepo uses Turborepo to manage `apps/backend` and `apps/web`. This setup simplifies sharing types and scripts and allows independent dev scripts for frontend and backend. The backend is intentionally minimal (Express + Drizzle) to focus on algorithm correctness and transactional safety. The frontend uses Next.js 15 App Router with Server Components for initial rendering and client components for interactive bits like booking forms and polling.

Trade-offs & Improvements

Time constraints prioritized correctness and testability over extensive UX and caching. With more time I would:
- Add Redis caching for price reads with careful invalidation on booking.
- Add E2E load testing and deployable Docker Compose setup for reproducible environments.
- Implement a small admin UI for live tuning and visual analytics.
- Use decimal/money libraries to avoid floating point edge cases for financial values.

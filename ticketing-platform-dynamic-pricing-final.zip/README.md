# Ticketing Platform — Final Submission

A full-stack event ticketing platform with dynamic pricing, Drizzle ORM + PostgreSQL backend, Next.js 15 frontend, and concurrency-safe booking.

## Stack
- Monorepo: Turborepo
- Frontend: Next.js 15 (App Router)
- Backend: Express (TypeScript)
- Database: PostgreSQL (Drizzle ORM)
- Testing: Jest + Supertest

## Prerequisites
- Node 20+ and pnpm (or npm/yarn)
- PostgreSQL (or use Docker Compose)
- (optional) Redis for caching

## Quick start (local)
1. Clone your fork:
```bash
git clone <your-fork-url>
cd ticketing-platform-monorepo-final
```
2. Copy env and configure:
```bash
cp .env.example .env
# edit .env to set DATABASE_URL and ADMIN_API_KEY etc.
```
3. If using Docker Compose:
```bash
docker-compose up -d
```
4. Install deps and run services:
```bash
pnpm install
pnpm -w dev
# Or run backend and web separately:
# cd apps/backend && pnpm install && pnpm dev
# cd apps/web && pnpm install && pnpm dev
```
5. Seed the DB:
```bash
cd apps/backend
pnpm seed
```
6. Open frontend: http://localhost:3000 and backend: http://localhost:4000

## Running tests
From repo root:
```bash
pnpm -w test
```
Important tests:
- `pricing.test.ts` — unit tests for pricing logic
- `concurrency.test.ts` — concurrent booking test proving oversell prevention

## Files to check
- `apps/backend/src/schema.ts` — database schema (Drizzle)
- `apps/backend/src/pricing.ts` — pricing engine
- `apps/backend/src/routes/bookings.ts` — transactional booking with FOR UPDATE locking
- `apps/backend/src/tests/concurrency.test.ts` — concurrency test

